﻿using System;
using System.ServiceModel;

namespace CreditServiceImplementation
{
    [ServiceContract]
    public interface ICreditService
    {
        [OperationContract]
        bool ChargePayment(String cardNumber, decimal amount);
    }

    public class CreditService : ICreditService
    {
        public bool ChargePayment(string cardNumber, decimal amount)
        {
            // Assume credit card always go through well
            return true;
        }
    }
}
