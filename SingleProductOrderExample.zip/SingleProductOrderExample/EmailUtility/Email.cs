﻿using System.Net;
using System.Net.Mail;
using System.Text;

namespace EmailUtility
{
    public class Email
    {
        private SmtpClient CreateSmtpClient()
        {
            SmtpClient client = new SmtpClient();
            client.Host = "smtp.mail.yahoo.com";
            client.EnableSsl = true;
            client.Port = 587;

            // Removed da_tou_li email password for privacy
            client.Credentials = new NetworkCredential("da_tou_li", "*********");
            return client;
        }

        private MailMessage CreateMailMessage(int qty)
        {
            MailMessage mail = new MailMessage("da_tou_li@yahoo.com", "da_tou_li@yahoo.com");

            mail.Subject = "Please ship order for the single product.";
            StringBuilder sb = new StringBuilder();

            sb.Append("Please ship ")
                .Append(qty).Append(" unit of the single product to the appropriate address");
            mail.Body = sb.ToString();

            return mail;
        }

        public virtual void SendEmail(int qty)
        {
            using (SmtpClient client = CreateSmtpClient())
            using (MailMessage mail = CreateMailMessage(qty))
            {
                client.Send(mail);
            }
        }
    }
}
