﻿using CreditServiceImplementation;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTest
{
    [TestClass]
    public class CreditServiceImplementationTest
    {
        [TestMethod]
        public void TestChargePayment()
        {
            CreditService service = new CreditService();

            string creditNumber = "1234567890";
            decimal amount = 100.00M;

            Assert.IsTrue(service.ChargePayment(creditNumber, amount));
        }
    }
}
