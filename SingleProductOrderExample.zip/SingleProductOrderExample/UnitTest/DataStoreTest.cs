﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using DataStore;
using System.Reflection;

namespace UnitTest
{
    [TestClass]
    public class DataStoreTest
    {
        private void resetProductQty()
        {
            var field = typeof(SingleProductStore).GetField("availableQty", BindingFlags.Static | BindingFlags.NonPublic);
            field.SetValue(null, 500);
        }

        [TestMethod]
        public void TestGetAvailableQty()
        {
            resetProductQty();

            var qty = SingleProductStore.GetAvailableQty();
            Assert.AreEqual(qty, 500);
        }

        [TestMethod]
        public void TestCheckAvailability()
        {
            resetProductQty();

            // Success case
            var beginQty = SingleProductStore.GetAvailableQty();
            var reqestedQty = 200;

            var checkResult = SingleProductStore.CheckAvailability(reqestedQty);
            Assert.IsTrue(checkResult);

            var endQty = SingleProductStore.GetAvailableQty();
            Assert.AreEqual(beginQty - reqestedQty, endQty);

            // Failure case
            resetProductQty();

            beginQty = SingleProductStore.GetAvailableQty();
            reqestedQty = 600;

            checkResult = SingleProductStore.CheckAvailability(reqestedQty);
            Assert.IsFalse(checkResult);

            endQty = SingleProductStore.GetAvailableQty();
            Assert.AreEqual(beginQty, endQty);
        }

        [TestMethod]
        public void TestCancelOrderQty()
        {
            resetProductQty();

            var beginQty = SingleProductStore.GetAvailableQty();
            var cancelQty = 200;

            SingleProductStore.CancelOrderQty(cancelQty);
            var endQty = SingleProductStore.GetAvailableQty();

            Assert.AreEqual(beginQty + cancelQty, endQty);
        }

        [TestCleanup()]
        public void Cleanup()
        {
            resetProductQty();
        }
    }
}
