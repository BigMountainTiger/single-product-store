﻿using EmailUtility;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace UnitTest
{
    [TestClass]
    public class EmailTest
    {
        [TestMethod]
        public void TestSendEmail()
        {
            string emailsent = null;

            var emailMock = new Mock<Email>();
            emailMock.Setup(e => e.SendEmail(It.IsAny<int>())).Callback((int x) => {
                emailsent = "Mail sent " + x.ToString();
            });

            emailMock.Object.SendEmail(100);

            Assert.AreEqual(emailsent, "Mail sent 100");
        }
    }
}
