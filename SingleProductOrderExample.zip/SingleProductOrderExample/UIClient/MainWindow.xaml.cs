﻿using DataStore;
using EmailUtility;
using System;
using System.Windows;
using System.Windows.Controls;
using UIClient.CreditService;
using UIClient.Properties;

namespace UIClient
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            this.Loaded += new RoutedEventHandler(MainWnd_Loaded);
        }

        void MainWnd_Loaded(object sender, RoutedEventArgs e)
        {
            DataContext = Settings.Default;
        }

        private void btnBookOrder_Click(object sender, RoutedEventArgs e)
        {
            int idex = cmbOrderQty.SelectedIndex;

            if (idex < 0)
            {
                MessageBox.Show("Please select the order quantity");
                return;
            }

            int qty = Convert.ToInt32(((ComboBoxItem)cmbOrderQty.SelectedItem).Content.ToString());
            
            if (!SingleProductStore.CheckAvailability(qty))
            {
                MessageBox.Show("We do not have enough inventory for you. Please try it later");
                return;
            }

            try {
                using (CreditServiceClient service = new CreditServiceClient())
                {
                    service.Open();
                    // Hard-coded credit card number and amount
                    string creditCard = "123456789";
                    decimal amount = 100.00M;
                    bool creditCharged = service.ChargePayment(creditCard, amount);

                    if (!creditCharged)
                    {
                        SingleProductStore.CancelOrderQty(qty);
                        throw new Exception("Unable to charge the credit card, please try it later");
                    }

                    try
                    {
                        Email email = new Email();
                        email.SendEmail(qty);
                    }
                    catch(Exception)
                    {
                        SingleProductStore.CancelOrderQty(qty);
                        throw new Exception("We are unable to inform the shipping department, please try it later");
                    }
                }

                MessageBox.Show("Your order has been processed");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
