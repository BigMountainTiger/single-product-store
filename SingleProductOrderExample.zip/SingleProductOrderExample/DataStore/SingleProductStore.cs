﻿using System;

namespace DataStore
{
    public sealed class SingleProductStore
    {
        private static Object synLock = new Object();
        private static int availableQty = 500;

        public static bool CheckAvailability(int qty)
        {
            lock(synLock)
            {
                if (availableQty < qty)
                {
                    return false;
                }

                availableQty = availableQty - qty;

                return true;
            }
        }

        public static void CancelOrderQty(int qty)
        {
            lock (synLock)
            {
                availableQty = availableQty + qty;
            }
        }

        public static int GetAvailableQty()
        {
            lock (synLock)
            {
                return availableQty;
            }
        }
    }
}
